package edu.spring.homeshare.persistence;

import java.util.HashMap;
import java.util.List;

import edu.spring.homeshare.domain.HouseVO;
import edu.spring.homeshare.domain.ReplyVO;
import edu.spring.homeshare.domain.ReportVO;

public interface ReplyDAO {
	int insert(ReplyVO vo);
	List<ReplyVO> select(int houseNo);
	int selectCount();
	int update(ReplyVO vo);
	int delete(int rno);
	
	int selectCountByHouseNo(int houseNo); //houseno�� �������� ��ġ�ϴ� ���� ����
	
	double selectAvgScore(int houseNo);
	
	
}
